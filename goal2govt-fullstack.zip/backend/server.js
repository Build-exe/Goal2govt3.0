require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const authRoutes = require('./routes/auth');

const app = express();
const PORT = process.env.PORT || 3000;
const FRONTEND_DIR = path.join(__dirname, '..', 'frontend');

// Which origins are allowed to call this API. Needed because the frontend
// (e.g. GitHub Pages) and this backend live on different URLs now — set
// every real frontend origin here, comma-separated, in .env.
// Example: CORS_ORIGIN=https://yourname.github.io,http://localhost:3000
const allowedOrigins = (process.env.CORS_ORIGIN || 'http://localhost:3000')
  .split(',')
  .map(s => s.trim())
  .filter(Boolean);

app.use(cors({
  origin(origin, callback) {
    // "origin" is undefined for same-origin/non-browser requests (curl, Postman) — allow those.
    if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
    callback(new Error(`Not allowed by CORS: ${origin}`));
  }
}));

app.use(express.json());

// Auth API used by the Sign Up / Log In modal and the mock-test gate.
app.use('/api', authRoutes);

// Serve the site itself (HTML/CSS/JS) from the same server, so the whole
// project runs with a single command and there's no CORS to configure.
app.use(express.static(FRONTEND_DIR));

app.listen(PORT, () => {
  console.log(`Goal2Govt running at http://localhost:${PORT}`);
});
