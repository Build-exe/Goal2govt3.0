# Goal2Govt

A government-exam-prep site: previous year papers, study material, a timed
mock test, and career/job info — split into a `frontend/` (static site) and
a `backend/` (Node.js/Express API for Sign Up, Log In and sessions).

## Folder structure

```
project/
├── frontend/          Static site — HTML, CSS, JS, question data
│   ├── index.html
│   ├── examprep.html
│   ├── jobsdetails.html
│   ├── mocktest.html
│   ├── about.html
│   ├── style.css
│   ├── script.js
│   └── questions-data.js
│
└── backend/            Express server: auth API + serves the frontend
    ├── server.js
    ├── package.json
    ├── .env.example
    ├── lib/db.js        JSON-file user storage (bcrypt-hashed passwords)
    ├── lib/mailer.js    Sends the password-reset email (nodemailer)
    ├── routes/auth.js   /api/signup, /api/login, /api/me, /api/logout,
    │                    /api/forgot-password, /api/reset-password
    └── data/users.json  Created/updated automatically — real accounts live here
```

## Running it

You only need to run the backend — it also serves the frontend files, so
there's a single server and no CORS setup required.

```bash
cd backend
npm install
cp .env.example .env      # optional: edit PORT or set your own JWT_SECRET
npm start
```

Then open **http://localhost:3000** — that's the whole site, home page
first.

## How auth works now

Previously, "Sign Up" / "Log In" just wrote to the browser's `localStorage`
— nothing was ever sent anywhere, so it wasn't real authentication.

Now:
- The **frontend** (`script.js`) calls the API — `/api/signup`, `/api/login`,
  `/api/me`, `/api/logout` — and stores only a signed session token
  (a JWT) in `localStorage`, not any account data.
- The **backend** hashes every password with bcrypt before saving it to
  `backend/data/users.json`, checks credentials on login, and issues a
  7-day JWT that the frontend sends back as `Authorization: Bearer <token>`
  on every request.
- Everything that already worked client-side (the auth modal, the "Hi,
  Name ▾" menu, gating the timed Mock Test behind sign-in) is unchanged —
  only what happens *after* you submit the form is now real.

## "Forgot password?"

The Log In form has a **Forgot password?** link. The flow:

1. Person enters their email → frontend calls `POST /api/forgot-password`.
2. If that email has an account, the server generates a one-time reset
   token (expires in 1 hour), saves a *hash* of it against the user, and
   emails a link: `SITE_URL/reset-password.html?token=...`.
3. The response is identical whether or not the email exists, so this
   can't be used to check who has an account.
4. `frontend/reset-password.html` reads the token from the URL, and on
   submit calls `POST /api/reset-password` with the token + new password.
   A used or expired token is rejected.

**To actually send the email**, fill in the SMTP settings in
`backend/.env` (see `.env.example`) — the easiest free option is a Gmail
account with an **App Password**:
Google Account → Security → 2-Step Verification → App passwords → generate
one for "Mail", then use that 16-character password as `SMTP_PASS` (not
your normal Gmail password).

If you leave SMTP blank, nothing breaks — the reset link is printed to
the backend's terminal instead, so you can still test the whole flow
locally without setting up email.

Also set `SITE_URL` in `.env` to wherever the site is actually running
(`http://localhost:3000` locally, your real domain once deployed) — it's
used to build the link inside the email.

## Swapping in a real database later

`backend/lib/db.js` is the only file that touches storage
(`readUsers()` / `writeUsers()`). To move off the JSON file and onto
Postgres, MongoDB, etc., rewrite those two functions — `routes/auth.js`
and the frontend don't need to change.

## Notes

- `backend/data/users.json` holds real (hashed) user accounts once people
  sign up — don't commit it if you push this to a public repo (it's
  already in `.gitignore`).
- Set a real `JWT_SECRET` in `.env` before deploying anywhere public; the
  default in the code is only a placeholder for local testing.
